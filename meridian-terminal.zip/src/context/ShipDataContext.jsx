import { createContext, useEffect, useState } from "react";

export const ShipDataContext = createContext(null);

const initialData = {
  heading: 127,
  cog: 125,
  sog: 7.2,
  lat: 32.7147, // farther offshore west of San Diego
  lon: -117.62,
  depth: 12.4,
  xte: 0.02, // nm
  nextWaypoint: {
    name: "PASS ENTRY",
    bearing: 138,
    range: 2.1, // nm
  },
  buoys: [
    { id: "B1", name: "West Pass Buoy", lat: -14.93, lon: -148.24, type: "port" },
    { id: "B2", name: "Lagoon Safe Water", lat: -14.92, lon: -148.20, type: "safe" },
    { id: "B3", name: "Shallow Patch", lat: -14.94, lon: -148.18, type: "warning" },
  ],
  aisTargets: [
    { mmsi: "520001234", name: "MV ARANUI 5", lat: -14.93, lon: -148.22, cog: 145, sog: 12.5, shipType: "Cargo" },
    { mmsi: "227001234", name: "SY MOANA", lat: -14.95, lon: -148.12, cog: 280, sog: 5.8, shipType: "Sailing" },
    { mmsi: "503001234", name: "FV TUHAA PAE", lat: -14.92, lon: -148.25, cog: 90, sog: 3.2, shipType: "Fishing" },
    { mmsi: "992501001", name: "TIKEHAU WEST", lat: -14.93, lon: -148.23, cog: 0, sog: 0, shipType: "AtoN" },
  ],
};

export const ShipDataProvider = ({ children }) => {
  const [data, setData] = useState(initialData);

  // Simulate NMEA-like drift.
  useEffect(() => {
    const id = setInterval(() => {
      setData((prev) => {
        const heading = (prev.heading + (Math.random() - 0.5) * 0.4 + 360) % 360;
        const cog = (prev.cog + (Math.random() - 0.5) * 0.3 + 360) % 360;
        const sog = Math.max(0, Math.min(15, prev.sog + (Math.random() - 0.5) * 0.2));
        const lat = prev.lat + (Math.random() - 0.5) * 0.00005;
        const lon = prev.lon + (Math.random() - 0.5) * 0.00005;
        const depth = Math.max(4, Math.min(60, prev.depth + (Math.random() - 0.5) * 0.2));
        const xte = Math.max(-0.25, Math.min(0.25, prev.xte + (Math.random() - 0.5) * 0.002));
        const aisTargets = (prev.aisTargets || []).map((t) => {
          const driftLat = t.lat + (Math.random() - 0.5) * 0.0003;
          const driftLon = t.lon + (Math.random() - 0.5) * 0.0003;
          const cog = (t.cog + (Math.random() - 0.5) * 1 + 360) % 360;
          const sog = Math.max(0, Math.min(20, t.sog + (Math.random() - 0.5) * 0.2));
          return { ...t, lat: driftLat, lon: driftLon, cog, sog };
        });
        return { ...prev, heading, cog, sog, lat, lon, depth, xte, aisTargets };
      });
    }, 200);
    return () => clearInterval(id);
  }, []);

  return <ShipDataContext.Provider value={{ data, setData }}>{children}</ShipDataContext.Provider>;
};
