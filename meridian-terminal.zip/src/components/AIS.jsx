import WidgetFrame from "./WidgetFrame.jsx";
import { useShipData } from "../hooks/useShipData.js";
import { useEffect, useRef, useState } from "react";
import { formatHeading } from "../utils/formatting.js";

const rangeOptions = [0.5, 1, 2, 4];

const AIS = () => {
  const data = useShipData();
  const [rangeNm, setRangeNm] = useState(2);
  const svgRef = useRef(null);

  const targets = data.aisTargets || [];

  const rings = rangeOptions.filter((r) => r <= rangeNm);

  const project = (lat, lon) => {
    const dx = (lon - data.lon) * 60 * Math.cos((data.lat * Math.PI) / 180); // nm approx
    const dy = (lat - data.lat) * 60; // nm
    const max = rangeNm;
    const clamp = (v) => Math.max(-max, Math.min(max, v));
    return { x: clamp(dx), y: clamp(dy) };
  };

  return (
    <WidgetFrame title="AIS Radar" color="#22c55e">
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 12, color: "#9ca3af" }}>
        <div>Targets: {targets.length}</div>
        <div style={{ display: "flex", gap: 8 }}>
          {rangeOptions.map((r) => (
            <button
              key={r}
              data-no-drag
              onClick={() => setRangeNm(r)}
              style={{
                background: r === rangeNm ? "#22c55e" : "transparent",
                color: r === rangeNm ? "#0b0b0f" : "#22c55e",
                border: `1px solid ${r === rangeNm ? "#22c55e" : "#1f2937"}`,
                borderRadius: 6,
                padding: "4px 8px",
                cursor: "pointer",
                fontFamily: "JetBrains Mono, monospace",
              }}
            >
              {r} nm
            </button>
          ))}
        </div>
      </div>
      <div
        ref={svgRef}
        style={{
          width: "100%",
          height: 360,
          background: "#0f172a",
          borderRadius: 10,
          border: "1px solid #1f2937",
          position: "relative",
        }}
      >
        <RadarSvg data={data} targets={targets} rangeNm={rangeNm} rings={rings} project={project} />
      </div>
      <div style={{ marginTop: 10, fontSize: 12, color: "#9ca3af" }}>COG {formatHeading(data.cog || 0)} / HDG {formatHeading(data.heading || 0)}</div>
    </WidgetFrame>
  );
};

const RadarSvg = ({ data, targets, rangeNm, rings, project }) => {
  const size = 360;
  const center = size / 2;
  const scale = (nm) => (nm / rangeNm) * (center - 10);

  const ownShip = (
    <g transform={`translate(${center},${center})`}>
      <circle r="6" fill="#22c55e" opacity="0.9" />
      <text y="-10" textAnchor="middle" fill="#22c55e" fontSize="12">
        ⛵
      </text>
    </g>
  );

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <rect width={size} height={size} fill="#0f172a" />
      {rings.map((r) => (
        <g key={r}>
          <circle cx={center} cy={center} r={scale(r)} stroke="#1f2937" strokeDasharray="4,4" fill="none" />
          <text x={center + scale(r)} y={center - 4} fill="#374151" fontSize="10" textAnchor="end">
            {r} nm
          </text>
        </g>
      ))}
      {ownShip}
      {targets.map((t) => {
        const { x, y } = project(t.lat, t.lon);
        const px = center + scale(x);
        const py = center - scale(y);
        const color = t.shipType === "Cargo" ? "#3b82f6" : t.shipType === "Sailing" ? "#22c55e" : t.shipType === "Fishing" ? "#eab308" : "#ec4899";
        const cogRad = ((t.cog || 0) * Math.PI) / 180;
        const vecLen = scale(Math.min(rangeNm * 0.2, (t.sog || 0) * 0.1));
        const vx = Math.sin(cogRad) * vecLen;
        const vy = -Math.cos(cogRad) * vecLen;
        return (
          <g key={t.mmsi || t.name} transform={`translate(${px},${py})`}>
            <line x1={0} y1={0} x2={vx} y2={vy} stroke={color} strokeWidth={2} opacity={0.8} />
            <circle r={6} fill={color} opacity="0.85" />
            <text y={-10} textAnchor="middle" fill="#e5e7eb" fontSize="10">
              {t.name || t.mmsi}
            </text>
          </g>
        );
      })}
    </svg>
  );
};

export default AIS;
