import WidgetFrame from "./WidgetFrame.jsx";
import { useShipData } from "../hooks/useShipData.js";
import { formatHeading, formatLat, formatLon, formatSpeed } from "../utils/formatting.js";

const XTEBar = ({ xte }) => {
  const limit = 0.25; // nm shown either side
  const clamped = Math.max(-limit, Math.min(limit, xte));
  const percent = ((clamped + limit) / (2 * limit)) * 100;
  const alarm = Math.abs(xte) > 0.1;
  return (
    <div style={{ marginTop: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#889" }}>
        <span>PORT</span>
        <span style={{ color: alarm ? "#f87171" : "#22c55e" }}>XTE {xte.toFixed(2)} nm</span>
        <span>STBD</span>
      </div>
      <div style={{ position: "relative", height: 12, marginTop: 6, background: "#11141d", borderRadius: 6, border: "1px solid #1f2933" }}>
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            bottom: 0,
            width: `${percent}%`,
            background: alarm ? "#7f1d1d" : "#0f3a2a",
            borderRadius: 6,
            transition: "width 0.2s ease",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: `${percent}%`,
            top: -4,
            width: 0,
            height: 0,
            borderLeft: "6px solid transparent",
            borderRight: "6px solid transparent",
            borderTop: `8px solid ${alarm ? "#ef4444" : "#22c55e"}`,
            transform: "translateX(-50%)",
            transition: "left 0.2s ease",
          }}
        />
      </div>
    </div>
  );
};

const Navigation = () => {
  const data = useShipData();
  const wp = data.nextWaypoint || { name: "--", bearing: 0, range: 0 };
  const caution = data.depth < 6;
  const danger = data.depth < 3;
  const depthColor = danger ? "#ef4444" : caution ? "#fbbf24" : "#22c55e";

  return (
    <WidgetFrame title="Navigation" color="#22c55e">
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
          <InfoBlock label="HDG" value={formatHeading(data.heading)} accent="#22c55e" large />
          <InfoBlock label="COG" value={formatHeading(data.cog)} />
          <InfoBlock label="SOG" value={formatSpeed(data.sog)} />
          <InfoBlock label="LAT" value={formatLat(data.lat)} />
          <InfoBlock label="LON" value={formatLon(data.lon)} />
          <InfoBlock label="DEPTH" value={`${data.depth.toFixed(1)} m`} accent={depthColor} />
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ fontSize: 11, color: "#9ca3af", letterSpacing: 0.5 }}>NEXT WPT</div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              background: "#0f172a",
              border: "1px solid #1f2937",
              borderRadius: 8,
              padding: "10px 12px",
            }}
          >
            <div style={{ display: "flex", flexDirection: "column" }}>
              <span style={{ color: "#e5e7eb", fontSize: 13, letterSpacing: 0.5 }}>{wp.name}</span>
              <span style={{ color: "#6b7280", fontSize: 11 }}>BRG {formatHeading(wp.bearing)}</span>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ color: "#22c55e", fontSize: 22, fontFamily: "JetBrains Mono, monospace" }}>{wp.range.toFixed(2)}</div>
              <div style={{ color: "#9ca3af", fontSize: 11 }}>nm</div>
            </div>
          </div>
          <XTEBar xte={data.xte || 0} />
        </div>
      </div>
    </WidgetFrame>
  );
};

const InfoBlock = ({ label, value, accent = "#9ca3af", large = false }) => (
  <div
    style={{
      background: "#0f172a",
      borderRadius: 8,
      padding: "10px 12px",
      border: "1px solid #1f2937",
      display: "flex",
      flexDirection: "column",
      gap: 6,
      minHeight: 64,
      justifyContent: "center",
    }}
  >
    <span style={{ color: "#6b7280", fontSize: 10, letterSpacing: 0.7 }}>{label}</span>
    <span
      style={{
        color: accent,
        fontSize: large ? 28 : 18,
        fontFamily: "JetBrains Mono, monospace",
        lineHeight: 1,
      }}
    >
      {value}
    </span>
  </div>
);

export default Navigation;
