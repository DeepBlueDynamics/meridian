import "./App.css";
import Chart from "./components/Chart.jsx";
import { ShipDataProvider } from "./context/ShipDataContext.jsx";

function App() {
  return (
    <ShipDataProvider>
      <div className="shell">
        <Chart />
      </div>
    </ShipDataProvider>
  );
}

export default App;
