import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Generate Copernicus COG URL for a lat/lon
function copernicusCogUrl(lat, lon) {
  const latBase = Math.floor(lat);
  const lonBase = Math.floor(lon);
  const latTag = `${latBase >= 0 ? "N" : "S"}${Math.abs(latBase).toString().padStart(2, "0")}_00`;
  const lonTag = `${lonBase >= 0 ? "E" : "W"}${Math.abs(lonBase).toString().padStart(3, "0")}_00`;
  const name = `Copernicus_DSM_COG_30_${latTag}_${lonTag}_DEM`;
  return `https://copernicus-dem-90m.s3.amazonaws.com/${name}/${name}.tif`;
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    // Serve dynamic MosaicJSON for TiTiler
    {
      name: 'mosaic-json-server',
      configureServer(server) {
        server.middlewares.use('/mosaic.json', (req, res) => {
          const url = new URL(req.url, 'http://localhost');
          const lat = parseFloat(url.searchParams.get('lat')) || 32.7;
          const lon = parseFloat(url.searchParams.get('lon')) || -117.2;
          const padding = parseInt(url.searchParams.get('padding')) || 2;

          // Generate COG URLs for the area
          const cogUrls = [];
          for (let dlat = -padding; dlat <= padding; dlat++) {
            for (let dlon = -padding; dlon <= padding; dlon++) {
              cogUrls.push(copernicusCogUrl(lat + dlat, lon + dlon));
            }
          }

          const mosaic = {
            mosaicjson: "0.0.2",
            name: "copernicus-dynamic",
            minzoom: 9,
            maxzoom: 14,
            bounds: [
              Math.floor(lon) - padding,
              Math.floor(lat) - padding,
              Math.floor(lon) + padding + 1,
              Math.floor(lat) + padding + 1
            ],
            tiles: cogUrls.reduce((acc, u, i) => { acc[i] = [u]; return acc; }, {})
          };

          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.end(JSON.stringify(mosaic));
        });
      }
    }
  ],
  server: {
    proxy: {
      "/anthropic": {
        target: "https://api.anthropic.com",
        changeOrigin: true,
        secure: true,
        rewrite: (path) => path.replace(/^\/anthropic/, ""),
        configure: (proxy, _options) => {
          proxy.on("proxyReq", (proxyReq, req, res) => {
            const apiKey =
              process.env.ANTHROPIC_API_KEY ||
              process.env.VITE_ANTHROPIC_API_KEY ||
              (req.headers["x-anthropic-key"] ? req.headers["x-anthropic-key"] : "");

            console.log("[proxy] API key sources:", {
              ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY ? "set" : "not set",
              VITE_ANTHROPIC_API_KEY: process.env.VITE_ANTHROPIC_API_KEY ? "set" : "not set",
              headerKey: req.headers["x-anthropic-key"] ? "set" : "not set",
              finalKey: apiKey ? `${apiKey.slice(0, 10)}...` : "NONE"
            });

            if (apiKey) {
              proxyReq.setHeader("x-api-key", apiKey);
            }
            proxyReq.setHeader("anthropic-version", "2023-06-01");
            // Remove headers that might confuse Anthropic
            proxyReq.removeHeader("x-anthropic-key");
            proxyReq.removeHeader("origin");
          });
          proxy.on("proxyRes", (proxyRes, req, res) => {
            console.log("[proxy] Response status:", proxyRes.statusCode);
            if (proxyRes.statusCode !== 200) {
              let body = "";
              proxyRes.on("data", (chunk) => body += chunk);
              proxyRes.on("end", () => console.log("[proxy] Error body:", body));
            }
          });
        },
      },
    },
  },
})
